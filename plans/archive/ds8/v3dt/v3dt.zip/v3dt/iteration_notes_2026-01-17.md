# V3DT Iteration Notes — 2026-01-17 (Family-room pitch sanity check)

## 1) Pitch-target experiment (family-room)
- Added `scripts/adjust_pitch_calibration.py` to generate preview calibrations with a pitch delta or target.
- Generated preview calibration targeting pitch -5° from the auto-tilt output:
  - `config/camera_calibration_preview_dewarp_fullfov_tilt_targetm5.json`
- Regenerated camInfo for the dewarp preview pipeline:
  - `config/v3dt_preview_charuco_fr_rtsp_dewarp/camInfo_family-room.yml`
- Ran DS8 preview and captured diagnostics:
  - Log: `diagnostics/v3dt_frames_fr_fullfov_tilt_targetm5.ndjson`
  - Snapshot: `diagnostics/v3dt_snapshot_20260117_002858.json`
  - Report: `diagnostics/v3dt_report_20260117_002906.md`

Result:
- Pitch-target run degraded family-room metrics (H ratio ~0.20, reproj ~39px),
  with stronger size collapse at lower image rows. Restored camInfo based on
  auto-tilt (`config/camera_calibration_preview_dewarp_fullfov_tilt.json`).

## 2) Streammux 720 tests
- Attempted a single-source 1280x720 pipeline:
  - `config/infer_v3dt_medium_preview_charuco_fr_rtsp_dewarp_720.yaml`
  - `config/v3dt/nvtracker_sv3dt_preview_charuco_fr_rtsp_dewarp_720.yml`
  - `config/v3dt_preview_charuco_fr_rtsp_dewarp_720/`
- Initial run failed because MapAnything engine is fixed batch=3; kept this config
  with `models.mapanything.enable=false` for single-source diagnostics only.

- Ran a multi-source 720 streammux test (keeps batch=3 to match MapAnything engine):
  - Pipeline: `config/infer_v3dt_medium_preview_charuco_fr_rtsp_dewarp_mux720.yaml`
  - Tracker: `config/v3dt/nvtracker_sv3dt_preview_charuco_fr_rtsp_dewarp_mux720.yml`
  - CamInfo: `config/v3dt_preview_charuco_fr_rtsp_dewarp_mux720/`
  - Log: `diagnostics/v3dt_frames_fr_mux720.ndjson`
  - Snapshot: `diagnostics/v3dt_snapshot_20260117_004242.json`
  - Report: `diagnostics/v3dt_report_20260117_004250.md`

Result:
- Reprojection improved (19.6px) but family-room height ratio stayed ~0.51 and
  depth ratio ~0.31. Streammux 1080 vs 720 is **not** the root cause of the
  size collapse; distortion/geometry mismatch remains.

## 3) Dewarper sanity check (inconclusive)
- Temporarily enabled `dewarp-dump-frames=1` in `config/dewarper_family_room_charuco_rtsp.txt`
  and captured RGBA dumps. Converted the latest dump to PNG and compared against
  an OpenCV-undistorted frame from `/home/mayor/Downloads/familyroomclip.mp4`.
- Basic pixel-diff comparison showed similar deltas to the original frame, but
  without exact frame alignment the result is not conclusive.
- Restored `dewarp-dump-frames=0` to avoid FPS impact.
